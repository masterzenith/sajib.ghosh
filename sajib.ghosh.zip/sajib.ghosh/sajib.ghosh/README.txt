# Environment setup:
 1. Install "Visual stiduo 2022" version and use C++ template to open this project.
 2. For Mac make sure "clang is installed.
 3. Run "sajib.ghosh.cpp" file from IDE run option or from terminal.

# Pre-requisites:
 1. To build a new test data, can use "reateBigFile" function.

# Solution explained:
 '''
 1. Define a struct to hold the data, the unique id and the associated value
 2. Add extraction >> and insertion << operators for easier IO
 3. Add 2 sort operator overloads for std::list::sort and std::lower_bound
 4. In main, get an std::istreameither to a given source file or std::cin
 5. Read the first X values and store them in the list as is. If there should be only these X values or less, then we have the solution already
 6. Sort the values in the list. The smalles value is now at the front of the list
 7. If the std::istream contains still data, then continue to read values
 8. If the new value id greater than than the smalled value in the list, then add the value to the list with insert sort
 9. Delete the smallest value at the front.
 10. After the initial sorting, all operations will be done in constant time. The number of input values does not add additional complexity. 
     However, Most time will be burned with reading data from the disk, if the file is huge. 
     For small files with 100'000 values or so, any other algorithm would be also fine.
 '''

# Deployment Process:
 ## we can create a DockerFile and deploy it to Docker container.
  1. Create a DockerFile with container creation cmds.
  2. Enlist all this required libraries to a requirement.txt file.
  3. Build the DockerFile and Check if the Container is running using Docker ps | grep dpp. Note: here "dpp" is container name defined in DockerFile.

# To-Do:
 1. Test coverage is remaining.